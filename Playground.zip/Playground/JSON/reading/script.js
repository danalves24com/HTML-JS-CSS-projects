	//const fs = require('fs')

	function daniel() {
		var Name = prompt("name")
		var Age = prompt("age")
		var intel = {Name, Age};
		var about = JSON.stringify(intel);	
		localStorage.setItem("testJ", about);
		//fs.writeFile('myjsonfile.json', about);
		var text = localStorage.getItem("testJ")
		var val = JSON.parse(text);
		console.log(text);
		alert(val)
		

	}