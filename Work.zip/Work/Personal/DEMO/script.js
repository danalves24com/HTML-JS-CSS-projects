function click() {
    console.log("clicked")
}